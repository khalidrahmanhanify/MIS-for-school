---
name: Icon request
about: Suggest a new icon for Remix Icons
title: ''
labels: ''
assignees: xiaochunjimmy

---

<!--Note: Before creating an icon request, please search to see if someone has already raised the same request. If there is an open request, please add a reaction 👍and subscribe the issue.-->

## Icon Request

* Icon name: 
* Tags of this icon: 
* Use case: 
* Screenshots of similar icons:
