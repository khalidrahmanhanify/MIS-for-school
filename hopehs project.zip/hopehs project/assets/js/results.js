document.addEventListener('DOMContentLoaded', () => {
    const classSelection = document.getElementById('class-selection');
    const studentSelection = document.getElementById('student-selection');
    const resultContainer = document.getElementById('result-container');
    const studentList = document.getElementById('student-list');
    const resultTableBody = document.getElementById('result-table').getElementsByTagName('tbody')[0];
    const studentNameSpan = document.getElementById('student-name');

    const backToClassSelectionBtn = document.getElementById('back-to-class-selection');
    const backToStudentSelectionBtn = document.getElementById('back-to-student-selection');
    const downloadResultBtn = document.getElementById('download-result-btn');

    const results = {
        "Class 1": {
            "Khalid Rahman": { "Math": "98", "Islamic Study": "95", "English": "100", "Life Skill": "100", "Art": "100", "Calligraphy": "95", "Dari": "96", "Quran Alkareem": "100" },
            "Mohammad Yasir": { "Math": "95", "Islamic Study": "98", "English": "98", "Life Skill": "97", "Art": "90", "Calligraphy": "95", "Dari": "96", "Quran Alkareem": "100" },
            "Murtaza": { "Math": "95", "Islamic Study": "98", "English": "98", "Life Skill": "97", "Art": "90", "Calligraphy": "95", "Dari": "96", "Quran Alkareem": "100" },
            "Sayed Maqsoud": { "Math": "95", "Islamic Study": "98", "English": "98", "Life Skill": "97", "Art": "90", "Calligraphy": "95", "Dari": "96", "Quran Alkareem": "100" },
            "Ahmad": { "Math": "95", "Islamic Study": "98", "English": "98", "Life Skill": "97", "Art": "90", "Calligraphy": "95", "Dari": "96", "Quran Alkareem": "100" },
            "Aryan": { "Math": "95", "Islamic Study": "98", "English": "98", "Life Skill": "97", "Art": "90", "Calligraphy": "95", "Dari": "96", "Quran Alkareem": "100" },
            "Muzammil": { "Math": "95", "Islamic Study": "98", "English": "98", "Life Skill": "97", "Art": "90", "Calligraphy": "95", "Dari": "96", "Quran Alkareem": "100" },
            "Elham": { "Math": "95", "Islamic Study": "98", "English": "98", "Life Skill": "97", "Art": "90", "Calligraphy": "95", "Dari": "96", "Quran Alkareem": "100" }

            // Add more students and their results
        },
        "Class 2": {
            "Khalil": { "Math": "98", "Islamic Study": "80", "English": "90", "Life Skill": "100", "Art": "100", "Calligraphy": "85", "Dari": "87", "Quran Alkareem": "98" },
            "Abdullah": { "Math": "93", "Islamic Study": "79", "English": "89", "Life Skill": "97", "Art": "90", "Calligraphy": "75", "Dari": "93", "Quran Alkareem": "89" },
            "Sorosh": { "Math": "94", "Islamic Study": "83", "English": "82", "Life Skill": "97", "Art": "90", "Calligraphy": "87", "Dari": "98", "Quran Alkareem": "90" },
            "Younus": { "Math": "89", "Islamic Study": "89", "English": "95", "Life Skill": "97", "Art": "90", "Calligraphy": "89", "Dari": "80", "Quran Alkareem": "98" },
            "Ali": { "Math": "85", "Islamic Study": "98", "English": "93", "Life Skill": "97", "Art": "90", "Calligraphy": "90", "Dari": "95", "Quran Alkareem": "92" },
            "Ahmad": { "Math": "78", "Islamic Study": "93", "English": "90", "Life Skill": "97", "Art": "90", "Calligraphy": "87", "Dari": "89", "Quran Alkareem": "91" },
            "Zahid": { "Math": "80", "Islamic Study": "90", "English": "80", "Life Skill": "97", "Art": "90", "Calligraphy": "90", "Dari": "96", "Quran Alkareem": "87" },
            "Rahmanullah": { "Math": "95", "Islamic Study": "67", "English": "89", "Life Skill": "97", "Art": "90", "Calligraphy": "75", "Dari": "86", "Quran Alkareem": "86" }
            // Add more students and their results
        },
        "Class 3": {
            "Hanif": { "Math": "98", "Islamic Study": "80", "English": "90", "Life Skill": "100", "Art": "100", "Calligraphy": "85", "Dari": "87", "Quran Alkareem": "98" },
            "Bilal": { "Math": "93", "Islamic Study": "79", "English": "89", "Life Skill": "97", "Art": "90", "Calligraphy": "75", "Dari": "93", "Quran Alkareem": "89" },
            "Sorosh": { "Math": "94", "Islamic Study": "83", "English": "82", "Life Skill": "97", "Art": "90", "Calligraphy": "87", "Dari": "98", "Quran Alkareem": "90" },
            "Edrees": { "Math": "89", "Islamic Study": "89", "English": "95", "Life Skill": "97", "Art": "90", "Calligraphy": "89", "Dari": "80", "Quran Alkareem": "98" },
            "Raihan": { "Math": "85", "Islamic Study": "98", "English": "93", "Life Skill": "97", "Art": "90", "Calligraphy": "90", "Dari": "95", "Quran Alkareem": "92" },
            "Usman": { "Math": "78", "Islamic Study": "93", "English": "90", "Life Skill": "97", "Art": "90", "Calligraphy": "87", "Dari": "89", "Quran Alkareem": "91" },
            "Ahmad Bilal": { "Math": "80", "Islamic Study": "90", "English": "80", "Life Skill": "97", "Art": "90", "Calligraphy": "90", "Dari": "96", "Quran Alkareem": "87" },
            "Rahmat": { "Math": "95", "Islamic Study": "67", "English": "89", "Life Skill": "97", "Art": "90", "Calligraphy": "75", "Dari": "86", "Quran Alkareem": "86" }
            // Add more students and their results
        },
        "Class 4": {
            "mustafa": { "Math": "98", "Islamic Study": "80", "English": "90", "Life Skill": "100", "Art": "100", "Calligraphy": "85", "Dari": "87", "Quran Alkareem": "98" },
            "Anas": { "Math": "93", "Islamic Study": "79", "English": "89", "Life Skill": "97", "Art": "90", "Calligraphy": "75", "Dari": "93", "Quran Alkareem": "89" },
            "Ali": { "Math": "94", "Islamic Study": "83", "English": "82", "Life Skill": "97", "Art": "90", "Calligraphy": "87", "Dari": "98", "Quran Alkareem": "90" },
            "Abdulrahman": { "Math": "89", "Islamic Study": "89", "English": "95", "Life Skill": "97", "Art": "90", "Calligraphy": "89", "Dari": "80", "Quran Alkareem": "98" },
            "Baheer": { "Math": "85", "Islamic Study": "98", "English": "93", "Life Skill": "97", "Art": "90", "Calligraphy": "90", "Dari": "95", "Quran Alkareem": "92" },
            "Gulab": { "Math": "78", "Islamic Study": "93", "English": "90", "Life Skill": "97", "Art": "90", "Calligraphy": "87", "Dari": "89", "Quran Alkareem": "91" },
            "Malik": { "Math": "80", "Islamic Study": "90", "English": "80", "Life Skill": "97", "Art": "90", "Calligraphy": "90", "Dari": "96", "Quran Alkareem": "87" },
            "Rahmat": { "Math": "95", "Islamic Study": "67", "English": "89", "Life Skill": "97", "Art": "90", "Calligraphy": "75", "Dari": "86", "Quran Alkareem": "86" }
            // Add more students and their results
        },
        "Class 5": {
            "Mohammad": { "Math": "98", "Islamic Study": "80", "English": "90", "Life Skill": "100", "Art": "100", "Calligraphy": "85", "Dari": "87", "Quran Alkareem": "98" },
            "Noorullah": { "Math": "93", "Islamic Study": "79", "English": "89", "Life Skill": "97", "Art": "90", "Calligraphy": "75", "Dari": "93", "Quran Alkareem": "89" },
            "Abdul": { "Math": "94", "Islamic Study": "83", "English": "82", "Life Skill": "97", "Art": "90", "Calligraphy": "87", "Dari": "98", "Quran Alkareem": "90" },
            "Habibullah": { "Math": "89", "Islamic Study": "89", "English": "95", "Life Skill": "97", "Art": "90", "Calligraphy": "89", "Dari": "80", "Quran Alkareem": "98" },
            "Hamid": { "Math": "85", "Islamic Study": "98", "English": "93", "Life Skill": "97", "Art": "90", "Calligraphy": "90", "Dari": "95", "Quran Alkareem": "92" },
            "Abdulrahman": { "Math": "78", "Islamic Study": "93", "English": "90", "Life Skill": "97", "Art": "90", "Calligraphy": "87", "Dari": "89", "Quran Alkareem": "91" },
            "Abdul Majid": { "Math": "80", "Islamic Study": "90", "English": "80", "Life Skill": "97", "Art": "90", "Calligraphy": "90", "Dari": "96", "Quran Alkareem": "87" },
            "Abdulghani": { "Math": "95", "Islamic Study": "67", "English": "89", "Life Skill": "97", "Art": "90", "Calligraphy": "75", "Dari": "86", "Quran Alkareem": "86" }
            // Add more students and their results
        },
        "Class 6": {
            "Qasim": { "Math": "98", "Islamic Study": "80", "English": "90", "Life Skill": "100", "Art": "100", "Calligraphy": "85", "Dari": "87", "Quran Alkareem": "98" },
            "Nasir": { "Math": "93", "Islamic Study": "79", "English": "89", "Life Skill": "97", "Art": "90", "Calligraphy": "75", "Dari": "93", "Quran Alkareem": "89" },
            "Ismail": { "Math": "94", "Islamic Study": "83", "English": "82", "Life Skill": "97", "Art": "90", "Calligraphy": "87", "Dari": "98", "Quran Alkareem": "90" },
            "Aminullah": { "Math": "89", "Islamic Study": "89", "English": "95", "Life Skill": "97", "Art": "90", "Calligraphy": "89", "Dari": "80", "Quran Alkareem": "98" },
            "Gulab": { "Math": "85", "Islamic Study": "98", "English": "93", "Life Skill": "97", "Art": "90", "Calligraphy": "90", "Dari": "95", "Quran Alkareem": "92" },
            "Sadiq": { "Math": "78", "Islamic Study": "93", "English": "90", "Life Skill": "97", "Art": "90", "Calligraphy": "87", "Dari": "89", "Quran Alkareem": "91" },
            "Wahidullah": { "Math": "80", "Islamic Study": "90", "English": "80", "Life Skill": "97", "Art": "90", "Calligraphy": "90", "Dari": "96", "Quran Alkareem": "87" },
            "Sharif": { "Math": "95", "Islamic Study": "67", "English": "89", "Life Skill": "97", "Art": "90", "Calligraphy": "75", "Dari": "86", "Quran Alkareem": "86" }
            // Add more students and their results
        },
        "Class 7": {
            "Mirwais": { "Math": "98", "Islamic Study": "80", "English": "90", "Life Skill": "100", "Art": "100", "Calligraphy": "85", "Dari": "87", "Quran Alkareem": "98" },
            "Mujtaba": { "Math": "93", "Islamic Study": "79", "English": "89", "Life Skill": "97", "Art": "90", "Calligraphy": "75", "Dari": "93", "Quran Alkareem": "89" },
            "Abdulaziz": { "Math": "94", "Islamic Study": "83", "English": "82", "Life Skill": "97", "Art": "90", "Calligraphy": "87", "Dari": "98", "Quran Alkareem": "90" },
            "Faridullah": { "Math": "89", "Islamic Study": "89", "English": "95", "Life Skill": "97", "Art": "90", "Calligraphy": "89", "Dari": "80", "Quran Alkareem": "98" },
            "Zabihullah": { "Math": "85", "Islamic Study": "98", "English": "93", "Life Skill": "97", "Art": "90", "Calligraphy": "90", "Dari": "95", "Quran Alkareem": "92" },
            "Akbar": { "Math": "78", "Islamic Study": "93", "English": "90", "Life Skill": "97", "Art": "90", "Calligraphy": "87", "Dari": "89", "Quran Alkareem": "91" },
            "Hafizullah": { "Math": "80", "Islamic Study": "90", "English": "80", "Life Skill": "97", "Art": "90", "Calligraphy": "90", "Dari": "96", "Quran Alkareem": "87" },
            "Said": { "Math": "95", "Islamic Study": "67", "English": "89", "Life Skill": "97", "Art": "90", "Calligraphy": "75", "Dari": "86", "Quran Alkareem": "86" }
            // Add more students and their results
        },
        "Class 8": {
            "Mirza": { "Math": "98", "Islamic Study": "80", "English": "90", "Life Skill": "100", "Art": "100", "Calligraphy": "85", "Dari": "87", "Quran Alkareem": "98" },
            "Naseer": { "Math": "93", "Islamic Study": "79", "English": "89", "Life Skill": "97", "Art": "90", "Calligraphy": "75", "Dari": "93", "Quran Alkareem": "89" },
            "Zahir": { "Math": "94", "Islamic Study": "83", "English": "82", "Life Skill": "97", "Art": "90", "Calligraphy": "87", "Dari": "98", "Quran Alkareem": "90" },
            "Jawad": { "Math": "89", "Islamic Study": "89", "English": "95", "Life Skill": "97", "Art": "90", "Calligraphy": "89", "Dari": "80", "Quran Alkareem": "98" },
            "Abdulhamid": { "Math": "85", "Islamic Study": "98", "English": "93", "Life Skill": "97", "Art": "90", "Calligraphy": "90", "Dari": "95", "Quran Alkareem": "92" },
            "Khlilullah": { "Math": "78", "Islamic Study": "93", "English": "90", "Life Skill": "97", "Art": "90", "Calligraphy": "87", "Dari": "89", "Quran Alkareem": "91" },
            "Basir": { "Math": "80", "Islamic Study": "90", "English": "80", "Life Skill": "97", "Art": "90", "Calligraphy": "90", "Dari": "96", "Quran Alkareem": "87" },
            "Qadir": { "Math": "95", "Islamic Study": "67", "English": "89", "Life Skill": "97", "Art": "90", "Calligraphy": "75", "Dari": "86", "Quran Alkareem": "86" }
            // Add more students and their results
        },
        "Class 9": {
            "Nasrat": { "Math": "98", "Islamic Study": "80", "English": "90", "Life Skill": "100", "Art": "100", "Calligraphy": "85", "Dari": "87", "Quran Alkareem": "98" },
            "Daud": { "Math": "93", "Islamic Study": "79", "English": "89", "Life Skill": "97", "Art": "90", "Calligraphy": "75", "Dari": "93", "Quran Alkareem": "89" },
            "Mohibullah": { "Math": "94", "Islamic Study": "83", "English": "82", "Life Skill": "97", "Art": "90", "Calligraphy": "87", "Dari": "98", "Quran Alkareem": "90" },
            "Mahdi": { "Math": "89", "Islamic Study": "89", "English": "95", "Life Skill": "97", "Art": "90", "Calligraphy": "89", "Dari": "80", "Quran Alkareem": "98" },
            "Dawood": { "Math": "85", "Islamic Study": "98", "English": "93", "Life Skill": "97", "Art": "90", "Calligraphy": "90", "Dari": "95", "Quran Alkareem": "92" },
            "Samillah": { "Math": "78", "Islamic Study": "93", "English": "90", "Life Skill": "97", "Art": "90", "Calligraphy": "87", "Dari": "89", "Quran Alkareem": "91" },
            "Ehsanullah": { "Math": "80", "Islamic Study": "90", "English": "80", "Life Skill": "97", "Art": "90", "Calligraphy": "90", "Dari": "96", "Quran Alkareem": "87" },
            "Sharafuddin": { "Math": "95", "Islamic Study": "67", "English": "89", "Life Skill": "97", "Art": "90", "Calligraphy": "75", "Dari": "86", "Quran Alkareem": "86" }
            // Add more students and their results
        },
        "Class 10": {
            "Hashmat": { "Math": "98", "Islamic Study": "80", "English": "90", "Life Skill": "100", "Art": "100", "Calligraphy": "85", "Dari": "87", "Quran Alkareem": "98" },
            "Hikmatullah": { "Math": "93", "Islamic Study": "79", "English": "89", "Life Skill": "97", "Art": "90", "Calligraphy": "75", "Dari": "93", "Quran Alkareem": "89" },
            "Tajuddin": { "Math": "94", "Islamic Study": "83", "English": "82", "Life Skill": "97", "Art": "90", "Calligraphy": "87", "Dari": "98", "Quran Alkareem": "90" },
            "Amanullah": { "Math": "89", "Islamic Study": "89", "English": "95", "Life Skill": "97", "Art": "90", "Calligraphy": "89", "Dari": "80", "Quran Alkareem": "98" },
            "Musa": { "Math": "85", "Islamic Study": "98", "English": "93", "Life Skill": "97", "Art": "90", "Calligraphy": "90", "Dari": "95", "Quran Alkareem": "92" },
            "Yousuf": { "Math": "78", "Islamic Study": "93", "English": "90", "Life Skill": "97", "Art": "90", "Calligraphy": "87", "Dari": "89", "Quran Alkareem": "91" },
            "Najibullah": { "Math": "80", "Islamic Study": "90", "English": "80", "Life Skill": "97", "Art": "90", "Calligraphy": "90", "Dari": "96", "Quran Alkareem": "87" },
            "Qseem": { "Math": "95", "Islamic Study": "67", "English": "89", "Life Skill": "97", "Art": "90", "Calligraphy": "75", "Dari": "86", "Quran Alkareem": "86" }
            // Add more students and their results
        },
        "Class 11": {
            "Najib": { "Math": "98", "Islamic Study": "80", "English": "90", "Life Skill": "100", "Art": "100", "Calligraphy": "85", "Dari": "87", "Quran Alkareem": "98" },
            "Shamsullah": { "Math": "93", "Islamic Study": "79", "English": "89", "Life Skill": "97", "Art": "90", "Calligraphy": "75", "Dari": "93", "Quran Alkareem": "89" },
            "Esmatullah": { "Math": "94", "Islamic Study": "83", "English": "82", "Life Skill": "97", "Art": "90", "Calligraphy": "87", "Dari": "98", "Quran Alkareem": "90" },
            "Hedayatullah": { "Math": "89", "Islamic Study": "89", "English": "95", "Life Skill": "97", "Art": "90", "Calligraphy": "89", "Dari": "80", "Quran Alkareem": "98" },
            "Azizullah": { "Math": "85", "Islamic Study": "98", "English": "93", "Life Skill": "97", "Art": "90", "Calligraphy": "90", "Dari": "95", "Quran Alkareem": "92" },
            "Nabi": { "Math": "78", "Islamic Study": "93", "English": "90", "Life Skill": "97", "Art": "90", "Calligraphy": "87", "Dari": "89", "Quran Alkareem": "91" },
            "Anwar": { "Math": "80", "Islamic Study": "90", "English": "80", "Life Skill": "97", "Art": "90", "Calligraphy": "90", "Dari": "96", "Quran Alkareem": "87" },
            "Rahmat": { "Math": "95", "Islamic Study": "67", "English": "89", "Life Skill": "97", "Art": "90", "Calligraphy": "75", "Dari": "86", "Quran Alkareem": "86" }
            // Add more students and their results
        },
        "Class 12": {
            "Qamar": { "Math": "98", "Islamic Study": "80", "English": "90", "Life Skill": "100", "Art": "100", "Calligraphy": "85", "Dari": "87", "Quran Alkareem": "98" },
            "Zalmay": { "Math": "93", "Islamic Study": "79", "English": "89", "Life Skill": "97", "Art": "90", "Calligraphy": "75", "Dari": "93", "Quran Alkareem": "89" },
            "Shrifullah": { "Math": "94", "Islamic Study": "83", "English": "82", "Life Skill": "97", "Art": "90", "Calligraphy": "87", "Dari": "98", "Quran Alkareem": "90" },
            "Walidullah": { "Math": "89", "Islamic Study": "89", "English": "95", "Life Skill": "97", "Art": "90", "Calligraphy": "89", "Dari": "80", "Quran Alkareem": "98" },
            "Hashmatullah": { "Math": "85", "Islamic Study": "98", "English": "93", "Life Skill": "97", "Art": "90", "Calligraphy": "90", "Dari": "95", "Quran Alkareem": "92" },
            "Ziaullah": { "Math": "78", "Islamic Study": "93", "English": "90", "Life Skill": "97", "Art": "90", "Calligraphy": "87", "Dari": "89", "Quran Alkareem": "91" },
            "Rahimullah": { "Math": "80", "Islamic Study": "90", "English": "80", "Life Skill": "97", "Art": "90", "Calligraphy": "90", "Dari": "96", "Quran Alkareem": "87" },
            "Hayatullah": { "Math": "95", "Islamic Study": "67", "English": "89", "Life Skill": "97", "Art": "90", "Calligraphy": "75", "Dari": "86", "Quran Alkareem": "86" }
            // Add more students and their results
        }

        // Add more classes and their students' results
    };

    let currentClass = '';
    let currentStudent = '';

    document.querySelectorAll('.class-card').forEach(card => {
        card.addEventListener('click', () => {
            currentClass = card.dataset.class;
            showStudentSelection(currentClass);
        });
    });

    backToClassSelectionBtn.addEventListener('click', () => {
        studentSelection.style.display = 'none';
        classSelection.style.display = 'block';
    });

    backToStudentSelectionBtn.addEventListener('click', () => {
        resultContainer.style.display = 'none';
        studentSelection.style.display = 'block';
    });

    downloadResultBtn.addEventListener('click', () => {
        downloadResult(currentClass, currentStudent);
    });

    function showStudentSelection(className) {
        studentList.innerHTML = '';
        for (const student in results[className]) {
            const studentCard = document.createElement('div');
            studentCard.className = 'student-card';
            studentCard.textContent = student;
            studentCard.addEventListener('click', () => {
                currentStudent = student;
                showResult(className, student);
            });
            studentList.appendChild(studentCard);
        }
        classSelection.style.display = 'none';
        studentSelection.style.display = 'block';
    }

    function showResult(className, studentName) {
        studentNameSpan.textContent = studentName;
        resultTableBody.innerHTML = '';
        const resultData = results[className][studentName];
        for (const subject in resultData) {
            const row = resultTableBody.insertRow();
            const subjectCell = row.insertCell(0);
            const gradeCell = row.insertCell(1);
            subjectCell.textContent = subject;
            gradeCell.textContent = resultData[subject];
        }
        studentSelection.style.display = 'none';
        resultContainer.style.display = 'block';
    }

    function downloadResult(className, studentName) {
        const resultData = results[className][studentName];
        let csvContent = "data:text/csv;charset=utf-8,Subject,Grade\n";
        for (const subject in resultData) {
            csvContent += `${subject},${resultData[subject]}\n`;
        }
        const fileName = `${studentName}_Result.csv`;
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", fileName);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
});
