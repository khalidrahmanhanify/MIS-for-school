/*=============== SHOW MENU ===============*/
const showMenu = (toggleId, navId) => {
    const toggle = document.getElementById(toggleId),
        nav = document.getElementById(navId)

    toggle.addEventListener('click', () => {
        // Add show-menu class to nav menu
        nav.classList.toggle('show-menu')

        // Add show-icon to show and hide the menu icon
        toggle.classList.toggle('show-icon')
    })
}

showMenu('nav-toggle', 'nav-menu')

// Hero section slider
document.addEventListener("DOMContentLoaded", function () {
    const slides = document.querySelector(".slides");
    const radios = document.querySelectorAll(".slides input");
    const manualButtons = document.querySelectorAll(".manual-btn");
    const prevButton = document.querySelector(".prev-btn");
    const nextButton = document.querySelector(".next-btn");
    let currentIndex = 0;
    let slideInterval;
    const slideTransitionTime = 2000; // Must match the transition time in CSS (2s)
    const animationDelay = 500; // Delay for text animation after slide transition (0.5s)

    function startSlideShow() {
        slideInterval = setInterval(() => {
            currentIndex = (currentIndex + 1) % radios.length;
            radios[currentIndex].checked = true;
            updateNavigationAuto(currentIndex);
            setTimeout(() => addAnimationToCurrentSlide(currentIndex), animationDelay);
        }, 10000); // Change slide every 5 seconds
    }

    function updateNavigationAuto(index) {
        const autoButtons = document.querySelectorAll(".navigation-auto div");
        autoButtons.forEach((btn, i) => {
            btn.style.background = i === index ? "orange" : "transparent";
        });
    }

    function resetSlideShow(index) {
        clearInterval(slideInterval);
        currentIndex = index;
        startSlideShow();
    }

    function addAnimationToCurrentSlide(index) {
        const currentSlide = slides.querySelectorAll(".slide")[index];
        const allSlides = slides.querySelectorAll(".slide");
        allSlides.forEach(slide => {
            slide.querySelector(".slide-content h1").classList.remove("text-reveal-h1");
            slide.querySelector(".slide-content p").classList.remove("text-reveal-p");
        });
        setTimeout(() => {
            currentSlide.querySelector(".slide-content h1").classList.add("text-reveal-h1");
        }, animationDelay);
        setTimeout(() => {
            currentSlide.querySelector(".slide-content p").classList.add("text-reveal-p");
        }, animationDelay + 500); // Delay p animation after h1 animation
    }

    manualButtons.forEach((btn, index) => {
        btn.addEventListener("click", () => {
            radios[index].checked = true;
            updateNavigationAuto(index);
            resetSlideShow(index);
            setTimeout(() => addAnimationToCurrentSlide(index), animationDelay);
        });
    });

    prevButton.addEventListener("click", () => {
        currentIndex = (currentIndex - 1 + radios.length) % radios.length;
        radios[currentIndex].checked = true;
        updateNavigationAuto(currentIndex);
        resetSlideShow(currentIndex);
        setTimeout(() => addAnimationToCurrentSlide(currentIndex), animationDelay);
    });

    nextButton.addEventListener("click", () => {
        currentIndex = (currentIndex + 1) % radios.length;
        radios[currentIndex].checked = true;
        updateNavigationAuto(currentIndex);
        resetSlideShow(currentIndex);
        setTimeout(() => addAnimationToCurrentSlide(currentIndex), animationDelay);
    });

    // Initialize
    startSlideShow();
    setTimeout(() => addAnimationToCurrentSlide(currentIndex), slideTransitionTime); // Ensure animation runs on the first slide initially
});

// hero section slider end

const search = () => {
    const searchbox = document.getElementById('search-item').value.toUpperCase();
    const storeStudents = document.getElementById('cards');
    const students = storeStudents.querySelectorAll('.card'); // Select all cards

    for (let i = 0; i < students.length; i++) {
        const nameElement = students[i].querySelector('h1');
        const fatherNameElement = students[i].querySelector('p');
        const idElement = students[i].querySelector('.student-info > div:nth-child(2) > h1');
        const gradeElement = students[i].querySelector('.student-info > div:nth-child(1) > h1');

        if (nameElement && fatherNameElement && idElement && gradeElement) {
            const name = nameElement.textContent.toUpperCase();
            const fatherName = fatherNameElement.textContent.toUpperCase();
            const id = idElement.textContent.toUpperCase();
            const grade = gradeElement.textContent.toUpperCase();

            console.log(`Card ${i}: Name - ${name}, Father's Name - ${fatherName}, ID - ${id}, Grade - ${grade}`);

            if (name.includes(searchbox) || fatherName.includes(searchbox) || id.includes(searchbox) || grade.includes(searchbox)) {
                students[i].style.display = ''; // Show card
            } else {
                students[i].style.display = 'none'; // Hide card
            }
        } else {
            console.log(`Error: Card ${i} missing name, father's name, ID, or grade element.`);
        }
    }
};

document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.student-btn').forEach(button => {
        button.addEventListener('click', () => {
            const cardInner = button.closest('.card-inner');
            cardInner.style.transform = 'rotateY(180deg)';
        });
    });

    document.querySelectorAll('.back-btn').forEach(button => {
        button.addEventListener('click', () => {
            const cardInner = button.closest('.card-inner');
            cardInner.style.transform = 'rotateY(0deg)';
        });
    });
});




const toTop = document.querySelector(".to-top")
window.addEventListener("scroll", () => {
    if (window.scrollY > 100) {
        toTop.classList.add("active");
    } else {
        toTop.classList.remove("active");
    }
})



