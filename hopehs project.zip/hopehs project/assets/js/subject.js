document.addEventListener('DOMContentLoaded', () => {
    const tabsBox = document.querySelector('.tabs-box');
    const arrowIcons = document.querySelectorAll('.icon i');

    let isDragging = false;
    let startX;
    let scrollLeft;
    let isScrolling = false;

    const handleIcons = () => {
        let maxScrollableWidth = tabsBox.scrollWidth - tabsBox.clientWidth;
        arrowIcons[0].parentElement.style.opacity = tabsBox.scrollLeft <= 0 ? '0' : '1'; // Change opacity instead of display
        arrowIcons[1].parentElement.style.opacity = maxScrollableWidth - tabsBox.scrollLeft <= 1 ? '0' : '1'; // Change opacity instead of display
    };

    // Hide the left icon by default
    arrowIcons[0].parentElement.style.opacity = '0';

    const scrollHandler = () => {
        isScrolling = true;
        handleIcons(); // Call handleIcons on scroll
        window.requestAnimationFrame(() => {
            isScrolling = false;
        });
    };

    const dragging = (e) => {
        if (!isDragging) return;
        const x = e.pageX - tabsBox.offsetLeft;
        const walk = (x - startX) * 2; // Adjust the sensitivity
        tabsBox.scrollLeft = scrollLeft - walk;
        e.preventDefault(); // Prevent text selection
        if (!isScrolling) {
            handleIcons(); // Call handleIcons during dragging
        }
    };

    const dragStart = (e) => {
        isDragging = true;
        startX = e.pageX - tabsBox.offsetLeft;
        scrollLeft = tabsBox.scrollLeft;
        tabsBox.classList.add('dragging');
        e.preventDefault(); // Prevent text selection
    };

    const dragStop = () => {
        isDragging = false;
        tabsBox.classList.remove('dragging');
        if (!isScrolling) {
            handleIcons(); // Call handleIcons after dragging stops
        }
    };

    tabsBox.addEventListener('mousedown', dragStart);
    tabsBox.addEventListener('mousemove', dragging);
    document.addEventListener('mouseup', dragStop);

    tabsBox.addEventListener('scroll', scrollHandler);

    arrowIcons.forEach(icon => {
        icon.addEventListener('click', () => {
            // if clicked icon is left, reduce 350 from tabsBox scrollLeft else add
            tabsBox.scrollLeft += icon.parentElement.id === 'left' ? -340 : 340;
            handleIcons();
        });
    });
});

// filter grades
// function filterObjects(c) {
//     var x, i;
//     x = document.getElementsByClassName("subject-card");
//     if (c == "all") {
//         for (i = 0; i < x.length; i++) {
//             x[i].style.display = "block";
//         }
//         return;
//     }
//     for (i = 0; i < x.length; i++) {
//         if (x[i].classList.contains(c)) {
//             x[i].style.display = "block";
//         } else {
//             x[i].style.display = "none";
//         }
//     }
// }
filterObjects("all");

function filterObjects(c) {
    var x, i;
    x = document.getElementsByClassName("subject-card");
    if (c == "all") {
        for (i = 0; i < x.length; i++) {
            x[i].style.display = "block";
        }
        return;
    }
    for (i = 0; i < x.length; i++) {
        if (x[i].classList.contains(c)) {
            x[i].style.display = "block";
        } else {
            x[i].style.display = "none";
        }
    }
}