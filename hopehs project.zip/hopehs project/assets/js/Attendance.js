document.addEventListener('DOMContentLoaded', () => {
    const classSelection = document.getElementById('class-selection');
    const classContainer = document.getElementById('class-container');
    const classTitle = document.getElementById('class-title');
    const attendanceTable = document.getElementById('attendance-table').getElementsByTagName('tbody')[0];
    const exportBtn = document.getElementById('export-btn');
    const backBtn = document.getElementById('back-btn');
    const addStudentBtn = document.getElementById('add-student-btn');

    const students = {
        "Class 1": [
            { name: "Khalid Rahman", fatherName: "Shamsulrahman" },
            { name: "Mohammad Yasir", fatherName: "Mohammad Ajmal" },
            { name: "Murtaza", fatherName: "Amir Mohammad" },
            { name: "Sayed Maqsoud", fatherName: "Sayed Mohammad" }
        ],
        "Class 2": [
            { name: "Aryan", fatherName: "Gul Habib" },
            { name: "Ahmad", fatherName: "Rahmanullah" },
            { name: "Muzammil", fatherName: "Said Ahmadullah" },
            { name: "Elham", fatherName: "Nasrat" }
        ],
        "Class 3": [
            { name: "Abdul Basit", fatherName: "Abdul Farid" },
            { name: "Shahram", fatherName: "Mohammad hashmat" },
            { name: "Sorosh", fatherName: "Sharafuddin" },
            { name: "Zahidullah", fatherName: "Asadullah" }
        ],
        "Class 4": [
            { name: "Younus", fatherName: "MuhsinShah" },
            { name: "Zakria", fatherName: "Abdulfatah" },
            { name: "Edrees", fatherName: "Mohammad Nasir" },
            { name: "Zakria", fatherName: "Khesraw" }
        ],
        "Class 5": [
            { name: "Abdulrahim", fatherName: "Abdul Haq" },
            { name: "said Abdullah", fatherName: "Said Ahmadullah" },
            { name: "Elham", fatherName: "Mohammad Hamid" },
            { name: "Zahidulah", fatherName: "Asadullah" }
        ],
        "Class 6": [
            { name: "Maqsood", fatherName: "Mahmood" },
            { name: "Ahmad Walid", fatherName: "Mohammad Kabir" },
            { name: "Bilal", fatherName: "Mohammad Hanif" },
            { name: "Safiullah", fatherName: "Ahmadullah" }
        ],
        "Class 7": [
            { name: "Misbah", fatherName: "Ghulamrabi" },
            { name: "Lemar", fatherName: "Salahudeen" },
            { name: "Sohile", fatherName: "Rabil" },
            { name: "Muzamil", fatherName: "Ghulamrabi" }
        ],
        "Class 8": [
            { name: "Zahinullah", fatherName: "Ghulam Nabi" },
            { name: "Hamidullah", fatherName: "Abdul Qadir" },
            { name: "Qudratullah", fatherName: "Fazal Karim" },
            { name: "Shafiqullah", fatherName: "Mohammad Akbar" }
        ],
        "Class 9": [
            { name: "Hidyatullah", fatherName: "Bismillah khan" },
            { name: "Naqibullah", fatherName: "Abdul Rashid" },
            { name: "Sabirullah", fatherName: "Hamkim Khan" },
            { name: "Najibullah", fatherName: "Ahmad Shah" }
        ],
        "Class 10": [
            { name: "Wahidullah", fatherName: "Ghulam Rasool" },
            { name: "Bashirullah", fatherName: "Karimullah" },
            { name: "Mahmoodullah", fatherName: "abdul Samad" },
            { name: "Samiullah", fatherName: "Ghulam Dastagir" }
        ],
        "Class 11": [
            { name: "Jalal", fatherName: "Habibullah" },
            { name: "azizullah", fatherName: "Ghulam Sarwar" },
            { name: "Latifullah", fatherName: "Mohammad Amin" },
            { name: "Nasirullah", fatherName: "Abdul Karim" }
        ],
        "Class 12": [
            { name: "Rafiullah", fatherName: "Shamsullah" },
            { name: "Haroonullah", fatherName: "Saifullah" },
            { name: "Faridullah", fatherName: "Rashid" },
            { name: "Mujibullah", fatherName: "Akhtar Mohammad" }
        ]
    };

    let currentClass = '';

    document.querySelectorAll('.class-card').forEach(card => {
        card.addEventListener('click', () => {
            currentClass = card.dataset.class;
            classTitle.textContent = currentClass;
            classSelection.style.display = 'none';
            classContainer.style.display = 'block';
            loadAttendance();
        });
    });

    backBtn.addEventListener('click', () => {
        classContainer.style.display = 'none';
        classSelection.style.display = 'flex';
        attendanceTable.innerHTML = '';
    });

    exportBtn.addEventListener('click', () => {
        exportToExcel();
    });

    addStudentBtn.addEventListener('click', () => {
        addNewStudent();
    });

    function loadAttendance() {
        const attendanceData = JSON.parse(localStorage.getItem(currentClass)) || [];
        attendanceTable.innerHTML = '';
        students[currentClass].forEach((student, index) => {
            const row = addAttendanceToTable(student.name, student.fatherName, attendanceData[index]?.status || 'Present', attendanceData[index]?.date || '', attendanceData[index]?.time || '');

            // Add click event listener to each student row
            row.addEventListener('click', () => {
                displayLast30DaysData(student.name);
            });
        });
    }

    function saveAttendance() {
        const attendanceData = [];
        attendanceTable.querySelectorAll('tr').forEach(row => {
            const name = row.cells[0].textContent;
            const fatherName = row.cells[1].textContent;
            const date = row.cells[2].textContent;
            const time = row.cells[3].textContent;
            const status = row.cells[4].querySelector('select').value;
            attendanceData.push({ name, fatherName, date, time, status });
        });
        localStorage.setItem(currentClass, JSON.stringify(attendanceData));
    }

    function addAttendanceToTable(name, fatherName, status, date, time) {
        const row = attendanceTable.insertRow();
        const nameCell = row.insertCell(0);
        const fatherNameCell = row.insertCell(1);
        const dateCell = row.insertCell(2);
        const timeCell = row.insertCell(3);
        const statusCell = row.insertCell(4);
        const editCell = row.insertCell(5);

        nameCell.textContent = name;
        fatherNameCell.textContent = fatherName;

        const today = new Date();
        const dateString = today.toLocaleDateString();
        const dayName = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][today.getDay()];

        dateCell.textContent = dateString;
        timeCell.textContent = dayName;

        const statusSelect = document.createElement('select');
        statusSelect.innerHTML = `
        <option value="Present" ${status === 'Present' ? 'selected' : ''}>Present</option>
        <option value="Absent" ${status === 'Absent' ? 'selected' : ''}>Absent</option>
    `;
        statusSelect.addEventListener('change', saveAttendance);
        statusCell.appendChild(statusSelect);

        const editButton = document.createElement('button');
        editButton.textContent = 'Edit';
        editButton.classList.add('edit-btn');
        editButton.addEventListener('click', () => editStudent(row));
        editCell.appendChild(editButton);

        saveAttendance();

        return row;
    }


    function addNewStudent() {
        const newName = prompt("Enter the student's name:");
        const newFatherName = prompt("Enter the father's name:");

        if (newName && newFatherName) {
            students[currentClass].push({ name: newName, fatherName: newFatherName });
            addAttendanceToTable(newName, newFatherName, 'Present', '', '');
        }
    }


    function editStudent(row) {
        const nameCell = row.cells[0];
        const fatherNameCell = row.cells[1];
        const editButton = row.cells[5].querySelector('button');

        if (editButton.textContent === 'Edit') {
            nameCell.innerHTML = `<input type="text" value="${nameCell.textContent}">`;
            fatherNameCell.innerHTML = `<input type="text" value="${fatherNameCell.textContent}">`;
            editButton.textContent = 'Save';
        } else {
            const newName = nameCell.querySelector('input').value;
            const newFatherName = fatherNameCell.querySelector('input').value;

            nameCell.textContent = newName;
            fatherNameCell.textContent = newFatherName;
            editButton.textContent = 'Edit';

            saveAttendance();
        }
    }

    function exportToExcel() {
        const attendanceData = JSON.parse(localStorage.getItem(currentClass)) || [];
        let csvContent = "data:text/csv;charset=utf-8,Name,Father's Name,Date,Day,Status\n";

        attendanceData.forEach(record => {
            csvContent += `${record.name},${record.fatherName},${record.date},${record.time},${record.status}\n`;
        });

        const today = new Date();
        const dateString = today.toLocaleDateString();
        const dayName = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][today.getDay()];

        const fileName = `${currentClass}_${dateString}_${dayName}.csv`;
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", fileName);
        document.body.appendChild(link);

        link.click();
        document.body.removeChild(link);
    }
});
